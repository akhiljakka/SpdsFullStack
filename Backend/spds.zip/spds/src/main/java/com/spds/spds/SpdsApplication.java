package com.spds.spds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpdsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpdsApplication.class, args);
	}

}
